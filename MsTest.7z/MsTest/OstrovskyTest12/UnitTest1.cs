﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OstrovskyExB20;
using System;
using System.Collections.Generic;

namespace OstrovskyTest12
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            List<DateTime> orderDates = new List<DateTime>
        {
            new DateTime(2019, 12, 12, 14, 43, 0),
            new DateTime(2019, 12, 01, 15, 05, 0),
            new DateTime(2019, 11, 04, 09, 01, 0)
        };

            string expected = "01.11.2019 0:00:00";


            string actual = DateFrequencyCounter.GetSortedDatesByFrequency(orderDates);

            Assert.AreEqual(expected, actual);
        }
    }
}
